# Vlaktes Hoenders

A modern Afrikaans poultry farm website, built with React and Vite.

## Run

```bash
npm install
npm run dev
```

## Deploy

Run `npm run build`; deploy the `dist/` folder on Netlify, Cloudflare Pages, or Render Static Sites. Build command: `npm run build`; publish directory: `dist`.

## Before publishing

1. WhatsApp is configured as 27665276031 (local: 066 527 6031) in `src.jsx`. Change `PHONE` there if needed.
2. Replace stock Unsplash photos with licensed photos of your own farm.
3. Confirm product offerings, breed names, pricing, collection options and contact information. Product descriptions are placeholders and do not assert current stock.
4. Check the site on mobile and desktop.

This is an original, modernized implementation inspired by a poultry-farm website, not a copy of its proprietary text or assets.

Business contact details: vlakteshoeders@gmail.com; 221 Willow Rd, Benoni AH, Benoni, 1509.
